package com.example.demo.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.example.demo.model.Shops;
import com.example.demo.repository.ShopsRepository;

@Controller
public class PostShops {
	@Autowired
	ShopsRepository shopsRepository;

	@PostConstruct
	public void init() {
		for (int i = 0; i < 20; i++) {
			Shops shop = new Shops();
			shop.setAreaNum(i);
			shop.setName("浦芝店"+i);
			if(i % 3 ==0) {
				shop.setCategory("日用品");
			}else if(i % 2 ==0) {
				shop.setCategory("サービス");
			}else {
				shop.setCategory("飲食店");
			}
			shopsRepository.saveAndFlush(shop);
		}
	}
}
