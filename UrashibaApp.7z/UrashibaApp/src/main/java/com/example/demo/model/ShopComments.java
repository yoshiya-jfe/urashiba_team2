package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.sun.istack.NotNull;

@Entity
@Table(name = "shop_comments")
public class ShopComments {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	@NotNull
	private long id;

	@ManyToOne
	private Users user;

	@ManyToOne
	private Shops shop;

	@Max(5)
	@Min(0)
	private int eval;


	private String comment;


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public Users getUser() {
		return user;
	}


	public void setUser(Users user) {
		this.user = user;
	}


	public Shops getShop() {
		return shop;
	}


	public void setShop(Shops shop) {
		this.shop = shop;
	}


	public int getEval() {
		return eval;
	}


	public void setEval(int eval) {
		this.eval = eval;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}




}
